import add_code_to_python_process
print(add_code_to_python_process.run_python_code(3736, "print(20)", connect_debugger_tracing=False))
