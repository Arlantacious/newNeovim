if __name__ == '__main__':
    x = 0  # before loop line
    for i in range(10):  # for line
        print(i)  # print line

    print('TEST SUCEEDED!')
