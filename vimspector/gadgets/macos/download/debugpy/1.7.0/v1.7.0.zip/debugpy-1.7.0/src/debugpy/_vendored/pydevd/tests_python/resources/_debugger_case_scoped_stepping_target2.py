a = 1


def method():
    b = 2


method()  # break here
c = 3
