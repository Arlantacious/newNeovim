import sys


def main():
    print('TEST SUCEEDED!')
    sys.exit(1)


main()
